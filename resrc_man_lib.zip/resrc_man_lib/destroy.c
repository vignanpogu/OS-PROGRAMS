#include<stdlib.h>
void destroy(int *temp)
{
	free(temp);
}
